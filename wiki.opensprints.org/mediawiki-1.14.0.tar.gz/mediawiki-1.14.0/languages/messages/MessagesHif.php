<?php
/** Fiji Hindi (Fiji Hindi/फ़ीजी हिन्दी)
 *
 * @ingroup Language
 * @file
 * @comment falls back to Fiji Hindi (Latin)
 */

$fallback = 'hif-latn';
