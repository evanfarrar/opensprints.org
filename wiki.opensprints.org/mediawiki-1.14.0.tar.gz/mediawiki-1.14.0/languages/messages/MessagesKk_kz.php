<?php
/** Kazakh (Kazakhstan) (‪Қазақша (Қазақстан)‬)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'kk-cyrl';
