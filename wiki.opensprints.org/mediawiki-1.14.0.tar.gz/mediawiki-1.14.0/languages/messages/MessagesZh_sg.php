<?php
/** ‪Chinese (Singapore) (‪中文(新加坡)‬)
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'zh-hans';
