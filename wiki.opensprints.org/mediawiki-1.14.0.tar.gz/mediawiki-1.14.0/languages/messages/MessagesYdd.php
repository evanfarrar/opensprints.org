<?php
/** Eastern Yiddish (מיזרח־ייִדיש)
 *
 * @ingroup Language
 * @file
 *
 */

$rtl = true;
$fallback = 'yi';
